﻿//=============================================================================================================================
//
// Copyright (c) 2015-2018 VisionStar Information Technology (Shanghai) Co., Ltd. All Rights Reserved.
// EasyAR is the registered trademark or trademark of VisionStar Information Technology (Shanghai) Co., Ltd in China
// and other countries for the augmented reality technology developed by VisionStar Information Technology (Shanghai) Co., Ltd.
//
//=============================================================================================================================

using System.Collections;
using System.IO;
using UnityEngine;
using EasyAR;

namespace Sample
{
    public class Script_VideoRecord : MonoBehaviour
    {
        private const string title = "Please enter KEY first!";
        private const string boxtitle = "===PLEASE ENTER YOUR KEY HERE===";
        private const string keyMessage = ""
            + "Steps to create the key for this sample:\n"
            + "  1. login www.easyar.com\n"
            + "  2. create app with\n"
            + "      Name: HelloARRecording (Unity)\n"
            + "      Bundle ID: cn.easyar.samples.unity.helloarrecording\n"
            + "  3. find the created item in the list and show key\n"
            + "  4. replace all text in TextArea with your key";

        public GUISkin skin;
        private bool isRecording = false;
        private bool isShowing = false;
        public bool StartShowMessage = false;

        private void Awake()
        {
            var EasyARBehaviour = FindObjectOfType<EasyARBehaviour>();
            if (EasyARBehaviour.Key.Contains(boxtitle))
            {
#if UNITY_EDITOR
                UnityEditor.EditorUtility.DisplayDialog(title, keyMessage, "OK");
#endif
                Debug.LogError(title + " " + keyMessage);
            }
            EasyARBehaviour.Initialize();

            if (ARBuilder.Instance.RecorderBehaviour)
                ARBuilder.Instance.RecorderBehaviour.StatusUpdate += OnRecorderUpdate;

            if (Application.platform == RuntimePlatform.Android)
            {
                DirectoryInfo dir = new DirectoryInfo("/sdcard/Movies/");
                if (!dir.Exists)
                    Directory.CreateDirectory("/sdcard/Movies/");
            }
        }

        void StartRecord()
        {
            string path_root = Application.persistentDataPath + "/";
            if (Application.platform == RuntimePlatform.Android)
                path_root = "/sdcard/Movies/";
            ARBuilder.Instance.RecorderBehaviour.OutputFile = path_root + "EasyAR_Recording_" + System.DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss") + ".mp4";

            ARBuilder.Instance.RecorderBehaviour.StartRecording();
            isRecording = true;
        }

        void StopRecord()
        {
            ARBuilder.Instance.RecorderBehaviour.StopRecording();
            isRecording = false;
            StartShowMessage = true;
        }

        void OnRecorderUpdate(RecorderBaseBehaviour recorder, RecorderBaseBehaviour.Status status, string msg)
        {
            Debug.Log("Recorder Status: " + status + " msg: " + msg);
            if (status == RecorderBaseBehaviour.Status.OnStopped || status == RecorderBaseBehaviour.Status.FailedToStart)
                isRecording = false;
        }

        void OnGUI()
        {
            if (StartShowMessage)
            {
                if (!isShowing)
                    StartCoroutine(showMessage());
                StartShowMessage = false;
            }
            if (isShowing)
            {
                if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
                    GUI.Box(new Rect(10, Screen.height / 2, Screen.width - 20, 60), "Recorded at " + ARBuilder.Instance.RecorderBehaviour.OutputFile);
                else
                    GUI.Box(new Rect(10, Screen.height / 2, Screen.width - 20, 60), "Recording is available only on Android & iOS. Win32 & Mac will be supported in later EasyAR versions.");
            }

            if (!isRecording)
            {
                if (GUI.Button(new Rect(Screen.width / 2 - 80, Screen.height - 85, 160, 80), "Record", skin.GetStyle("Button")))
                    StartRecord();
            }
            else
            {
                if (GUI.Button(new Rect(Screen.width / 2 - 80, Screen.height - 85, 160, 80), "Stop", skin.GetStyle("Button")))
                    StopRecord();
            }
        }

        IEnumerator showMessage()
        {
            isShowing = true;
            yield return new WaitForSeconds(2f);
            isShowing = false;
        }
    }
}
