﻿using UnityEngine;
using System.Collections;

public class script_menu : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    void OnGUI()
    {
        if (GUI.Button(new Rect(0, 10, 160, 60), "退出"))
        {
            Application.Quit();
        }

        if (GUI.Button(new Rect(0, 70, 160, 60), "scene_ImageTarget"))
        {
            Application.LoadLevel("scene_ImageTarget");
        }

        if (GUI.Button(new Rect(0, 130, 160, 60), "scene_ImageTarget_Muti"))
        {
            Application.LoadLevel("scene_ImageTarget_Muti");
        }

        if (GUI.Button(new Rect(0, 190, 160, 60), "scene_Model_shrink_drag"))
        {
            Application.LoadLevel("scene_Model_shrink_drag");
        }

        if (GUI.Button(new Rect(0, 250, 160, 60), "scene_Model_animate"))
        {
            Application.LoadLevel("scene_Model_animate");
        }

        if (GUI.Button(new Rect(0, 310, 160, 60), "scene_vedioRecord"))
        {
            Application.LoadLevel("scene_Model_animate_vedioRecord");
        }

        if (GUI.Button(new Rect(0, 370, 160, 60), "HelloARRecording"))
        {
            Application.LoadLevel("HelloARRecording");
        }
        
    }
}
