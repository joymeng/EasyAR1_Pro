﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class script_guaishou_animation : MonoBehaviour {

    public Animation anim;

    // Use this for initialization
    void Start () {
        anim = GetComponent<Animation>();
	}
	
	// Update is called once per frame
	void Update ()
    {
        //if (!anim.isPlaying)
        //{
        //    anim.Play("idle");
        //}
	}

    private int index = 0;
    void OnMouseDown()
    {
        index++;
        if (index >= 7) index = 1;
        
        if(index==1) anim.Play("idle");
        else if(index==2) anim.Play("run");
        else if (index==3) anim.Play("attack");
        else if (index==4) anim.Play("hit");
        else if (index==5) anim.Play("fly");
        else if (index==6) anim.Play("dead");
    }

}
