﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class script_back : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    void OnGUI()
    {
        if (GUI.Button(new Rect(0, 10, 160, 60), "scene_Menu"))
        {
            Application.LoadLevel("scene_Menu");
            //Application.Quit();
        }
    }
}
