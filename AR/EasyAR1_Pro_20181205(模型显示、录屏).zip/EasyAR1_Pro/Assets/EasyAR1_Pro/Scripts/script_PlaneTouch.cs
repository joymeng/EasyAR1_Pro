﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class script_PlaneTouch : MonoBehaviour {

    private Vector3 clickPosion;
    public float speed = 5f;

    // Use this for initialization
    void Start () {
        clickPosion = transform.position;
    }
	
	// Update is called once per frame
	void Update () {
        if (Input.touchCount > 0)
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.GetTouch(0).position);
            RaycastHit hit;
            Physics.Raycast(ray, out hit);
            try
            {
                if (hit.collider.tag == "Ground") //获取点击位置的世界坐标
                {
                    Vector3 v = hit.point;
                    clickPosion = new Vector3(v.x, transform.position.y, v.z);
                    transform.LookAt(clickPosion);
                }
            }
            catch
            {
            }

            //iTween.MoveTo(gameObject, clickPosion, 4f);
        }
    }
}
